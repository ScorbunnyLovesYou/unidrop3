const { MessageButton } = require("discord-buttons");
const { MessageEmbed } = require("discord.js");
module.exports = {
  name: "invite",
  aliases: ["inv"],
  run: async (client, message, args) => {
   /* let invbutton = new MessageButton().setStyle("url").setLabel("Disney").setURL(`https://discord.com/api/oauth2/authorize?client_id=885950249473024000&permissions=36768832&scope=bot`);

    let invbutton2 = new MessageButton().setStyle("url").setLabel("Disney 2").setURL("https://discord.com/api/oauth2/authorize?client_id=885951753315565648&permissions=36768832&scope=bot")

    let invbutton3 = new MessageButton().setStyle("url").setLabel("Disney 3").setURL("https://discord.com/api/oauth2/authorize?client_id=885952326559465472&permissions=36768832&scope=bot")
    
    let invbutton4 = new MessageButton().setStyle("url").setLabel("Disney Cute").setURL("https://discord.com/api/oauth2/authorize?client_id=886212016392536075&permissions=3459136&scope=bot")*/

    const invitemsg = new MessageEmbed().setColor(client.colors.main).setAuthor(`${client.user.tag}`, client.user.displayAvatarURL()) .setDescription("<a:arrow:936319224320786442> Want to invite the bot [Click here](https://discord.com/oauth2/authorize?client_id=927873038018547723&permissions=70282305&scope=bot)");

    message.channel.send(invitemsg)//({ embed: invitemsg, button: [invbutton, invbutton2, invbutton3, invbutton4] });
  },
};
