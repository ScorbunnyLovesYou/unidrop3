module.exports = require("../config.json").colors;
