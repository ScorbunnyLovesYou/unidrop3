const { MessageEmbed } = require("discord.js");
const discord = require("discord.js");
module.exports = {

    name: "ping",

    aliases: ["pi"],

    run:async (client, message, args) => {

        const latency = Date.now() - message.createdTimestamp;

        message.channel.send(new MessageEmbed().setColor(client.colors.main).setDescription(`<a:arrow:936319224320786442> Latency 1: ${client.ws.ping}ms <a:arrow:936319224320786442> Latency 2: ${latency}ms`));                     

    }

};