const { MessageEmbed } = require("discord.js")
 
const { default_prefix } = require("../config.json");
module.exports = {
  name: "guildCreate",
   async execute(client, guild, message, args) {
    const checkPrefix = await client.db.get(`prefix_${guild.id}`)
    const prefix = await checkPrefix ? checkPrefix : client.config.default_prefix

    let embed = new MessageEmbed()
      .setAuthor(`${client.user.username} `, client.user.displayAvatarURL())
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 2048 }))

      .setDescription(`Thanks for adding me my prefix is > but you can cahnge with >prefix new prefix`)
      .setColor(client.colors.success)
      .setFooter(`Hope you enjoy`)
      //return message.channels.send(`https://discord.gg/G3Rc6mSzmW`, embed)

    const channel = guild.channels.cache.find(channel => channel.type === 'text' && channel.permissionsFor(guild.me).has('SEND_MESSAGES', 'ADMINISTRATOR'));
    channel.send(embed)
    channel.send('https://discord.gg/bSNe5qY3hf').catch(err => { })


    /*const ID = "913008335920459781";
     //const channel = client.channels.cache.get(client.config.log);
    //const sowner = `${guild.owner.user}`;
    const embed1 = new MessageEmbed()
      .setTitle("New Server Joined!")
      .setThumbnail(`${guild.iconURL({ dynamic: true, size: 2048 })}`)
      .addField(`Server Name:`, `${guild.name}`)
      .addField(`Server ID:`, `${guild.id}`)
      .addField(`Members:`, `${guild.memberCount}`)
      .setTimestamp()
      .setColor(client.colors.success)
      .setFooter(`My new Server Count - ${client.guilds.cache.size}`);

    client.channels.cache.get(client.config.log).send(embed1)*/
  }
}