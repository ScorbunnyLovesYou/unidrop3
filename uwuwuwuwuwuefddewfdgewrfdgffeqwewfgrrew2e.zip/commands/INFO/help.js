const { MessageEmbed } = require("discord.js");
const { MessageButton } = require("discord-buttons");

module.exports = {
  name: "help",
  aliases: ["h"],
  run: async (client, message, args) => {
    const checkPrefix = await client.db.get(`prefix_${message.guild.id}`)
    const prefix = await checkPrefix ? checkPrefix : client.config.default_prefix

    let invbutton = new MessageButton().setStyle("url").setLabel("Invite Me").setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=70282305&scope=bot`);
    let invbutton2 = new MessageButton().setStyle("url").setLabel("Support Server").setURL(`https://discord.gg/bSNe5qY3hf`);
    let invbutton3 = new MessageButton().setStyle("url").setLabel("Website").setURL(`https://music.unidrop.repl.co/`);
    let invbutton4 = new
      MessageButton().setStyle("url").setLabel("Premium").setURL("https://discord.gg/bSNe5qY3hf")

    const embed = new MessageEmbed()
      .setColor(client.colors.main)
      .setThumbnail(client.user.displayAvatarURL())
      .setAuthor(`${client.user.username} Command's`)
      .setDescription(`Unidrop🌌 | Discord Music Bot With Many Features!`)
      .addField("<a:music_1:936319225054756874> Music", "`join`, `leave`, `clear`, `loop`, `move`, `nowplaying`, `pause`, `play`, `previous`, `queue`, `remove`, `resume`, `search`, `skip`, `seek`, `stop`, `volume`")
      .addField("<a:dance:934186782289981481> Filters", "`bass`, `bassboost`, `deepbass`, `nightcore`, `pitch`, `pop`, `reset`, `soft`, `speed`, `vaporwave`")
      .addField("<a:verify:934186781727920198> Config", "`prefix`, `24/7`")
      .addField("<a:Premium:937324441820626994> Premium", "`premium`, `validity`, `reedem`")
      .addField("<a:diamond:934186779102310430> Utility ", "`help`, `ping`, `invite`, `stats`, `node`")
       .addField("<a:crown:937325157050089472> Owner", "`addPremium`, `checkcode`, `gencode`, `RemovePremium`, `eval`")
      .setTimestamp();

    message.channel.send({ embed: embed, button: [invbutton, invbutton2, invbutton3, invbutton4] });
  },
};
