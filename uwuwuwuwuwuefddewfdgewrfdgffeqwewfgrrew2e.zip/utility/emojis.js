module.exports = require("../config.json").emojis;
