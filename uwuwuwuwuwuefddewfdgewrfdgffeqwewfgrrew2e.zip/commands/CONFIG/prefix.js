const { default_prefix } = require("../../config.json");
const { MessageEmbed } = require("discord.js");
module.exports = { 
  name: "prefix",
  category: "moderation",
  //userPermission: ["ADMINISTRATOR"],
  usage: "prefix <new-prefix>",
  description: "Change the guild prefix",
  run: async (client, message, args) => {
    if (!args[0]) {
      return message.channel.send({ embed: { color: client.colors.error, description: " <a:purple:936319223783915701>  | Provide new prefix you want to set" } });
    }
if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(new MessageEmbed()
    .setColor(client.colors.error)
    .setDescription(` <a:purple:936319223783915701> > | You don't have \`ADMINISTRATOR\` permission for this Command!`)
    );
    if (args[1]) {
      return message.channel.send({ embed: { color: client.colors.error, /*description: " <a:purple:936319223783915701>  | You can not set prefix a double argument"*/ } });
    }

    if (args[0].length > 5) {
      return message.channel.send({ embed: { color: client.colors.error, description: " <a:purple:936319223783915701>  | Prefix must not be longer than 5 characters" } });
    }

    if (args.join("reset") === default_prefix) {
      client.db.delete(`prefix_${message.guild.id}`);
      return await message.channel.send({ embed: { color: client.colors.error, description: " <a:purple:936319223783915701>  | Successfully prefix reset" } });
    }

    client.db.set(`prefix_${message.guild.id}`, args[0]);
    await message.channel.send({ embed: { color: client.colors.error, description: ` <a:purple:936319223783915701> | Successfully prefix set to **\`${args[0]}\`**` } });
  },
};
